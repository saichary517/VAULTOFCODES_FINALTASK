def add_task(task_list):
    task_description = input("Enter task description: ")
    task_list.append({"description": task_description, "completed": False})
    print("Task added successfully!\n")

def delete_task(task_list):
    display_tasks(task_list)
    try:
        task_index = int(input("Enter task number to delete: ")) - 1
        if 0 <= task_index < len(task_list):
            del task_list[task_index]
            print("Task deleted successfully!\n")
        else:
            print("Invalid task number. Please try again.\n")
    except ValueError:
        print("Invalid input. Please enter a number.\n")

def display_tasks(task_list):
    if not task_list:
        print("No tasks.")
    else:
        print("Tasks:")
        for index, task in enumerate(task_list, start=1):
            status = "✓" if task["completed"] else " "
            print(f"{index}. [{status}] {task['description']}")
        print()

def complete_task(task_list):
    display_tasks(task_list)
    try:
        task_index = int(input("Enter task number to mark as complete: ")) - 1
        if 0 <= task_index < len(task_list):
            task_list[task_index]["completed"] = True
            print("Task marked as complete!\n")
        else:
            print("Invalid task number. Please try again.\n")
    except ValueError:
        print("Invalid input. Please enter a number.\n")

def main():
    tasks = []

    while True:
        print("*To-Do List Application-Final Task*")
        print("=================================")
        print("Choose an choice:")
        print("1. Add a task")
        print("2. Delete a task")
        print("3. Display tasks")
        print("4. Mark a task as complete")
        print("5. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            add_task(tasks)
        elif choice == "2":
            delete_task(tasks)
        elif choice == "3":
            display_tasks(tasks)
        elif choice == "4":
            complete_task(tasks)
        elif choice == "5":
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please enter a valid option.\n")

if __name__ == "__main__":
    main()
